package com.praktikum.actions;
import java.util.Scanner;

public interface AdminActions {
    void manageitem(Scanner scanner);
    void manageUser(Scanner scanner);
}
