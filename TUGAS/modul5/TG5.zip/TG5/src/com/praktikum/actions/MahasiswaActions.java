package com.praktikum.actions;
import java.util.Scanner;

public interface MahasiswaActions {
    void reportItem(Scanner scanner);
    void viewReportItems(Scanner scanner);
}